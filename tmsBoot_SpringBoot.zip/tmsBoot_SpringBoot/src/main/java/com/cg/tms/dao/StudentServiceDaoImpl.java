package com.cg.tms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.tms.entity.Program;
import com.cg.tms.entity.Student;
import com.cg.tms.exception.ErrorMessages;
import com.cg.tms.exception.ProgramException;

@Repository
@Transactional
public class StudentServiceDaoImpl implements StudentServiceDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public boolean enrollStudent(Student student, Program program) throws ProgramException {
		entityManager.persist(student);
		return true;
	}

	@Override
	public boolean removeStudent(int studentId, int trainingProgramId) throws ProgramException {
		Student student = entityManager.find(Student.class, studentId);
		if (null == student) {
			throw new ProgramException(ErrorMessages.MESSAGE10);
		}
		/***
		 * Bug Detected!! Correction Required
		 */
		entityManager.remove(student);
		return true;
	}

}
