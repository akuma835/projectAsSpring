package com.cg.tms.enums;

public enum Skills {
	C,JAVA,PYTHON,ANGULAR

}
