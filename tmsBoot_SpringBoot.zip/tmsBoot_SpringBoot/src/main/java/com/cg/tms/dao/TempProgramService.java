package com.cg.tms.dao;

import java.util.Set;

import com.cg.tms.entity.Program;
import com.cg.tms.exception.ProgramException;

public interface TempProgramService {
	public boolean create(Program o) throws ProgramException;

	/**
	 * 
	 */
	public boolean update(Program o) throws ProgramException ;

	/**
	 * @throws ProgramException 
	 * 
	 */
	public Program retrieve(int o) throws ProgramException;

	/**
	 * @throws ProgramException 
	 * 
	 */
	public boolean delete(Program o) throws ProgramException;

	/**
	 * @throws ProgramException 
	 * 
	 */
	public Set<Program> retrieveAll() throws ProgramException;

}
