package com.cg.tms.dao;
import java.time.LocalDate;
import java.util.*;

import com.cg.tms.entity.Feedback;

/**
 * 
 */
public class FeedbackServiceDaoImpl implements CrudService<Feedback> {

	@Override
	public boolean create(Feedback o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(Feedback o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Feedback retrieve(int o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean delete(Feedback o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Set<Feedback> retrieveAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Feedback> getCheapProgramAtLocationOnSpecifiedDate(String centerName, int charge, LocalDate date) {
		// TODO Auto-generated method stub
		return null;
	}

	


}