package com.cg.tms.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.tms.entity.Student;
import com.cg.tms.exception.ProgramException;
import com.cg.tms.service.StudentService;
import com.cg.tms.util.LogUtils;

@RestController
public class StudentController {
	
	@Autowired
	private StudentService studentservice;
	final private Logger log = LogUtils.getLogger();

	@PostMapping(value = "/enrollStudent", consumes = "application/json", produces = "application/json")
	public boolean removeStudent(@RequestBody @Valid Student student) throws ProgramException {

		studentservice.enrollStudent(student, student.getProgram());
		log.info("Student Enrolled:: ACCESSED");
		return true;
	}

	@GetMapping(value = "/removeStudent/{sid},{pid}", produces = "application/json")
	public boolean removeStudent(@PathVariable("sid") int studentId, @PathVariable("pid") int programId)
			throws ProgramException {

		studentservice.removeStudent(studentId, programId);
		log.info("Student Removed:: ACCESSED");
		return true;
	}

}