package com.cg.tms.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import com.cg.tms.entity.Program;
import com.cg.tms.exception.ProgramException;

/**
 * 
 */
public interface TrainingProgramService {

	/**
	 * @throws ProgramException 
	 * 
	 */
	public boolean createProgram(Program trainingProgram) throws ProgramException;

	/**
	 * @throws ProgramException 
	 * 
	 */
	public boolean deleteTrainingProgram(int trainingId) throws ProgramException;

	public boolean modifyTrainingProgram(Program trainingProgram) throws ProgramException;
	
	public Program retrieveTrainingProgram(int trainingId) throws ProgramException;
	
	public Set<Program> retrieveAllTrainingProgram() throws ProgramException;

	public List<Program> getCheapProgramAtLocationOnSpecifiedDate(String centerName,int charge,LocalDate date)throws ProgramException;
	

}