package com.cg.tms.beans;

import com.cg.tms.entity.Employee;

public class Admin extends Employee {

	/**
	 * Default constructor
	 */
	public Admin() {
	}

}