package com.cg.tms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tms.dao.IFetchAllDetails;
import com.cg.tms.dao.StudentServiceDao;
import com.cg.tms.dao.StudentServiceDaoImpl;
import com.cg.tms.entity.Program;
import com.cg.tms.entity.Student;
import com.cg.tms.exception.ErrorMessages;
import com.cg.tms.exception.ProgramException;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	private StudentServiceDao studentOpn;

	public StudentServiceImpl() {
		this.studentOpn = new StudentServiceDaoImpl();
	}

	public StudentServiceImpl(IFetchAllDetails<Student> studentOpn) {
		super();
		this.studentOpn = new StudentServiceDaoImpl();
	}

	@Override
	public boolean enrollStudent(Student student, Program program) throws ProgramException {
		boolean status = false;
		if (null == student || null == program) {
			throw new ProgramException(ErrorMessages.MESSAGE13);
		}
		status = studentOpn.enrollStudent(student, program);
		return status;
	}

	@Override
	public boolean removeStudent(int studentId, int trainingProgramId) throws ProgramException {
		if (!(studentId>0) && !(trainingProgramId>0)) {
			throw new ProgramException(ErrorMessages.MESSAGE18);
		}
		boolean status = studentOpn.removeStudent(studentId, trainingProgramId);
		return status;
	}

}
