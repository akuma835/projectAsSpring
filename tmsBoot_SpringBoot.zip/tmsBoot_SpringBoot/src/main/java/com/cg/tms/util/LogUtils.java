package com.cg.tms.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cg.tms.TmsBootApplication;

public class LogUtils {
	private static Logger log = LoggerFactory.getLogger(TmsBootApplication.class);

	public static Logger getLogger() {
		return log;
	}

}
