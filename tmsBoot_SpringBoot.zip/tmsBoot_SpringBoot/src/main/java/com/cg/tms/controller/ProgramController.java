package com.cg.tms.controller;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.tms.entity.Program;
import com.cg.tms.exception.ErrorMessages;
import com.cg.tms.exception.ProgramException;
import com.cg.tms.service.TrainingProgramService;
import com.cg.tms.util.LogUtils;

@RestController
public class ProgramController {

	@Autowired
	private TrainingProgramService traingingProgramOpn;

	final private Logger log = LogUtils.getLogger();

	@GetMapping(value = "/programs", produces = "application/json")
	public Set<Program> getPrograms() throws ProgramException {
		log.info("Get All Programs Access: STARTED at");
		Set<Program> programs = traingingProgramOpn.retrieveAllTrainingProgram();
		log.info("Get All Programs Access: SUCEESS");
		return programs;
	}

	@GetMapping(value = "/getCondition/{a},{b},{c}", produces = "application/json")
	public List<Program> getConditionalProgram(@PathVariable("a") String centerName, @PathVariable("b") int charge,
			@PathVariable("c") String dateStr) throws ProgramException {
		LocalDate date = null;
		try {
			date = LocalDate.parse(dateStr);
		} catch (DateTimeParseException e) {
			throw new ProgramException(ErrorMessages.MESSAGE16,HttpStatus.BAD_REQUEST);
		}

		List<Program> programs = traingingProgramOpn.getCheapProgramAtLocationOnSpecifiedDate(
				centerName.substring(1, centerName.length() - 1), charge, date);
		return programs;
	}

	@PostMapping(value = "/addprogram", consumes = "application/json", produces = "application/json")
	public Program addPrograms(@RequestBody Program program) throws ProgramException {

		boolean flag = traingingProgramOpn.createProgram(program);
		if (flag) {
			log.info("Program created by JSON objects id" + program.getTrainingId());
		}
		return program;
	}

	@GetMapping(value = "/getprogram/{id}", produces = "application/json")
	public Program getProgram(@PathVariable("id") int trainingId) throws ProgramException {

		Program program = traingingProgramOpn.retrieveTrainingProgram(trainingId);
		return program;
	}

	@DeleteMapping(value = "/delprogram/{id}", produces = "application/json")
	public boolean delProgram(@PathVariable("id") int trainingId) throws ProgramException {

		traingingProgramOpn.deleteTrainingProgram(trainingId);
		log.info("Program Deleted by id" + trainingId);
		return true;
	}
	
	@PutMapping(value = "/updateprogram", consumes = "application/json", produces = "application/json")
	public Program updatePrograms(@RequestBody Program program) throws ProgramException {
		if(program.getTrainingStartDate().isBefore(LocalDate.now())) {
			throw new ProgramException(ErrorMessages.MESSAGE17);
		}
		
		boolean flag = traingingProgramOpn.modifyTrainingProgram(program);
		if (flag) {
			log.info("Program updated by JSON objects id" + program.getTrainingId());
		}
		return program;
	}
	

}
